package com.example.inventoryappcharlescampbell;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {

    EditText itemName;
    EditText itemDesc;
    EditText itemPrice;
    EditText itemQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        itemName = findViewById(R.id.NewItemName);
        itemDesc = findViewById(R.id.NewItemDescription);
        itemPrice = findViewById(R.id.NewItemPrice);
        itemQuantity = findViewById(R.id.NewItemQuantity);
    }

    public void addNewItem(View view) {
        String name = itemName.getText().toString();
        String description = itemDesc.getText().toString();
        String price = itemPrice.getText().toString();
        String quantity = itemQuantity.getText().toString();
        InventoryActivity.databaseAdapter.addItem(name, description, price, quantity);
        startActivity(new Intent(AddActivity.this, InventoryActivity.class));
        finish();
    }
}
