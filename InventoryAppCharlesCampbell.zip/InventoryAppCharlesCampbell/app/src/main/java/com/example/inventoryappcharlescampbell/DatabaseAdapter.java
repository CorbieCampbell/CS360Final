package com.example.inventoryappcharlescampbell;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;
public class DatabaseAdapter {
    DatabaseHelper helper;
    static SQLiteDatabase db;
    Context context;

    public DatabaseAdapter(Context context) {
        helper = new DatabaseHelper(context);
        db = helper.getWritableDatabase();
        this.context = context;
    }

    public SimpleCursorAdapter populateListViewFromDB() {
        String[] columns = {DatabaseHelper.KEY_ROWID,
                            DatabaseHelper.KEY_NAME,
                            DatabaseHelper.KEY_DESCRIPTION,
                            DatabaseHelper.KEY_PRICE,
                            DatabaseHelper.KEY_QUANTITY};
        Cursor cursor = db.query(DatabaseHelper.TABLE_ITEMS, columns,null, null,null, null, null, null);
        cursor.moveToFirst();
        String[] fromFieldNames = new String[] {
                DatabaseHelper.KEY_ROWID, DatabaseHelper.KEY_NAME, DatabaseHelper.KEY_QUANTITY
        };
        int[] toViewIDs = new int[] {R.id.item_id, R.id.item_name, R.id.item_quantity};
        SimpleCursorAdapter listAdapter = new SimpleCursorAdapter(
                context,
                R.layout.single_item,
                cursor,
                fromFieldNames,
                toViewIDs
        );
        return listAdapter;
    }

    // Functions for Login Database
    public boolean insertUser(String username, String password) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_USERNAME, username);
        contentValues.put(DatabaseHelper.KEY_PASSWORD, password);
        long result = db.insert(DatabaseHelper.TABLE_USERS, null, contentValues);
        return result != -1;
    }

    public static String checkLogin(String username, String password) {
        String[] columns = {DatabaseHelper.KEY_USERNAME};
        String selection = "USERNAME=? AND PASSWORD = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        String result = null;
        if (cursor!=null && cursor.moveToFirst()) {
            result = cursor.getString(cursor.getColumnIndex(DatabaseHelper.KEY_USERNAME));
            cursor.close();
        }
        return result;
    }

    // Functions for the Inventory Database
    public int updateNameNew(long id, String name) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_NAME, name);
        String[] whereArgs = {""+id};
        int count = db.update(DatabaseHelper.TABLE_ITEMS, contentValues, DatabaseHelper.KEY_ROWID+ "=?", whereArgs);
        return count;
    }

    public int updateDescNew(long id, String description) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_DESCRIPTION, description);
        String[] whereArgs = {""+id};
        int count = db.update(DatabaseHelper.TABLE_ITEMS, contentValues, DatabaseHelper.KEY_ROWID+ "=?", whereArgs);
        return count;
    }

    public int updatePriceNew(long id, String price) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_PRICE, price);
        String[] whereArgs = {""+id};
        int count = db.update(DatabaseHelper.TABLE_ITEMS, contentValues, DatabaseHelper.KEY_ROWID+ "=?", whereArgs);
        return count;
    }

    public int updateQuantityNew(long id, String quantity) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_QUANTITY, quantity);
        String[] whereArgs = {""+id};
        int count = db.update(DatabaseHelper.TABLE_ITEMS, contentValues, DatabaseHelper.KEY_ROWID+ "=?", whereArgs);
        return count;
    }

    void addItem(String name, String description, String price, String quantity) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_NAME, name);
        contentValues.put(DatabaseHelper.KEY_DESCRIPTION, description);
        contentValues.put(DatabaseHelper.KEY_PRICE, price);
        contentValues.put(DatabaseHelper.KEY_QUANTITY, quantity);
        long result = db.insert(DatabaseHelper.TABLE_ITEMS, null, contentValues);
        if (result == -1) {
            Toast.makeText(context, "Failed to add new item", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "New item was added to inventory!", Toast.LENGTH_SHORT).show();
        }
    }

    public int deleteItemData(long id) {
        String[] whereArgs = {""+id};
        int count = db.delete(DatabaseHelper.TABLE_ITEMS, DatabaseHelper.KEY_ROWID + "=?", whereArgs);
        return count;
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        private static final String DATABASE_NAME = "mydb.db";
        private static final int DATABASE_VERSION = 1;

        // Database Table for user logins
        private static final String TABLE_USERS = "users";
        private static final String KEY_ID = "id";
        private static final String KEY_USERNAME = "username";
        private static final String KEY_PASSWORD = "password";

        // Database Table for item inventory
        private static final String TABLE_ITEMS = "inventory";
        private static final String KEY_ROWID = "_id";
        private static final String KEY_NAME = "name";
        private static final String KEY_DESCRIPTION = "description";
        private static final String KEY_PRICE = "price";
        private static final String KEY_QUANTITY = "quantity";


        // Call to create the user login table
        private static final String SQL_CREATE_USERS_TABLE =
                "create table " + TABLE_USERS + " (" +
                        KEY_ID + " integer primary key autoincrement," +
                        KEY_USERNAME + " text," +
                        KEY_PASSWORD + " text)";

        // Call to create the inventory table
        private static final String SQL_CREATE_INVENTORY_TABLE =
                "create table " + TABLE_ITEMS + " (" +
                        KEY_ROWID + " integer primary key autoincrement," +
                        KEY_NAME + " text," +
                        KEY_DESCRIPTION + " text," +
                        KEY_PRICE + " text," +
                        KEY_QUANTITY + " text)";
        private final Context context;

        public DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
            this.context = context;
            //Toast.makeText(context, "Database constructor called", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            try{
                // Create both tables when the database is created
                db.execSQL(SQL_CREATE_USERS_TABLE);
                db.execSQL(SQL_CREATE_INVENTORY_TABLE);
                Toast.makeText(context, "onCreate called", Toast.LENGTH_SHORT).show();
            }catch (SQLException e){
                Toast.makeText(context, ""+e, Toast.LENGTH_SHORT).show();
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            try{
                Toast.makeText(context, "onUpgrade called", Toast.LENGTH_SHORT).show();
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
                onCreate(db);
            }catch (SQLException e){
                Toast.makeText(context, ""+e, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
