package com.example.inventoryappcharlescampbell;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {
    @SuppressLint("StaticFieldLeak")
    static DatabaseAdapter databaseAdapter;
    public ListView inventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        databaseAdapter = new DatabaseAdapter(this);
        inventoryList = findViewById(R.id.inventoryList);
        final SimpleCursorAdapter listAdapter = databaseAdapter.populateListViewFromDB();
        inventoryList.setAdapter(listAdapter);
        inventoryList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Cursor cursor = (Cursor) listAdapter.getItem(position);
                String name = cursor.getString(1);
                String description = cursor.getString(2);
                String price = cursor.getString(3);
                String quantity = cursor.getString(4);
                Intent intent = new Intent(InventoryActivity.this, ItemActivity.class);
                intent.putExtra("id", id);
                intent.putExtra("name", name);
                intent.putExtra("description", description);
                intent.putExtra("price", price);
                intent.putExtra("quantity", quantity);
                startActivity(intent);
                finish();
            }
        });
    }
    public void addItem(View view) {
        Intent intent = new Intent(InventoryActivity.this, AddActivity.class);
        startActivity(intent);
        finish();
    }

    public void notifButton(View view) {
        Intent intent = new Intent(InventoryActivity.this, SMSActivity.class);
        startActivity(intent);
        finish();
    }
}
