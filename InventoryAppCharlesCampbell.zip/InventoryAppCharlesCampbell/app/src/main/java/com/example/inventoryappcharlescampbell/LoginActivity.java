package com.example.inventoryappcharlescampbell;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginActivity extends AppCompatActivity{
    Button LoginBtn, RegisterBtn;
    EditText LoginUsername, LoginPassword;
    DatabaseAdapter databaseAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        LoginBtn = findViewById(R.id.LoginButton);
        RegisterBtn = findViewById(R.id.RegisterButton);
        LoginUsername = findViewById(R.id.usernameLogin);
        LoginPassword = findViewById(R.id.passwordLogin);
        databaseAdapter = new DatabaseAdapter(this);

        // Listener for LoginBtn
        LoginBtn.setOnClickListener(view -> {
            // Call LoginActivity function
            String username = LoginUsername.getText().toString().trim();
            String password = LoginPassword.getText().toString().trim();
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "No text in username or password.\nPlease type in your credentials.", Toast.LENGTH_LONG).show();
            }
            else {
                String loggedInUserName = DatabaseAdapter.checkLogin(username, password);
                if (loggedInUserName!=null) {
                    Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    Toast.makeText(LoginActivity.this, "Username/Password not found.\nplease try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Listener for RegisterBtn
        RegisterBtn.setOnClickListener(view -> {
            String username = LoginUsername.getText().toString().trim();
            String password = LoginPassword.getText().toString().trim();
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "No text in username or password.\nPlease type in your credentials.", Toast.LENGTH_LONG).show();
            }
            else {
                boolean result = databaseAdapter.insertUser(username, password);
                if (result == false) {
                    Toast.makeText(LoginActivity.this, "Failed to add new user", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LoginActivity.this, "User created!\nPlease use credentials to login.", Toast.LENGTH_LONG).show();
                }
            }
            LoginUsername.getText().clear();
            LoginPassword.getText().clear();
        });
    }
}
