package com.example.inventoryappcharlescampbell;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class ItemActivity extends AppCompatActivity {
    EditText updateName;
    EditText updateDescription;
    EditText updatePrice;
    EditText updateQuantity;
    long id;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item);
        // Get the variables
        id = getIntent().getExtras().getLong("id");
        String name = getIntent().getExtras().getString("name");
        String description = getIntent().getExtras().getString("description");
        String price = getIntent().getExtras().getString("price");
        String quantity = getIntent().getExtras().getString("quantity");
        // Get the activity elements
        updateName = findViewById(R.id.updateName);
        updateDescription = findViewById(R.id.updateDescription);
        updatePrice = findViewById(R.id.updatePrice);
        updateQuantity = findViewById(R.id.updateQuantity);
        // Put the variables in the activity elements
        updateName.setText(name);
        updateDescription.setText(description);
        updatePrice.setText(price);
        updateQuantity.setText(quantity);
    }

    public void editItem(View view) {
        // Get the new (or the same as before) data input by the user
        String name = updateName.getText().toString();
        String description = updateDescription.getText().toString();
        String price = updatePrice.getText().toString();
        String quantity = updateQuantity.getText().toString();
        // Call the update methods to input the data into the database
        InventoryActivity.databaseAdapter.updateNameNew(id, name);
        InventoryActivity.databaseAdapter.updateDescNew(id, description);
        InventoryActivity.databaseAdapter.updatePriceNew(id, price);
        InventoryActivity.databaseAdapter.updateQuantityNew(id, quantity);

        if (Objects.equals(quantity, "0")) {
            String message = "Quantity of " + name + " is now 0.";
            SMSActivity.sendSMS(message);
        }

        // Return back to the Inventory list view
        startActivity(new Intent(ItemActivity.this, InventoryActivity.class));
        finish();
    }

    public void deleteItem(View view) {
        // Call the delete function for the database item
        InventoryActivity.databaseAdapter.deleteItemData(id);
        // Return back to the Inventory list view
        startActivity(new Intent(ItemActivity.this, InventoryActivity.class));
        finish();
    }
}
